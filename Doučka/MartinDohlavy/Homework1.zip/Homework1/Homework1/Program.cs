﻿var main = new Homework1.Filter();
main.Run();