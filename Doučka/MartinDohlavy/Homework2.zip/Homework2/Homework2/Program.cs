﻿var main = new Homework2.GetPeople();
main.Run();